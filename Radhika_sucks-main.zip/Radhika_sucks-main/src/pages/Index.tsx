
import TriviaGame from '@/components/TriviaGame';

const Index = () => {
  return <TriviaGame />;
};

export default Index;
