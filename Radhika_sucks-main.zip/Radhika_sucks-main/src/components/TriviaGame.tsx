import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface TriviaData {
  question: string;
  answer: string;
  hints: string[];
}

const TriviaGame = () => {
  const [guessesLeft, setGuessesLeft] = useState(5);
  const [currentGuess, setCurrentGuess] = useState('');
  const [gameStatus, setGameStatus] = useState<'playing' | 'won' | 'lost'>('playing');
  const [revealedHints, setRevealedHints] = useState<boolean[]>([false, false, false]);
  const [submittedGuesses, setSubmittedGuesses] = useState<string[]>([]);
  const [dailyStreak, setDailyStreak] = useState(0);

  // Sample trivia data - in a real app, this would come from an API
  const triviaData: TriviaData = {
    question: "Guess the Movie from this Incredibly Random Out-Of-Context movie review: Property Owner? Animal Lover? Willing to fight a dragon for you? Big Sexy Build? The Perfect man.",
    answer: "Shrek",
    hints: [
      "Genre:Kids/Animated",
      "Release Year:2001", 
      "Radhika's Hint:I love this Movie's soundtrack."
    ]
  };

  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });

  // Load game state and streak from localStorage on component mount
  useEffect(() => {
    const savedStreak = localStorage.getItem('dailyTriviaStreak');
    const savedGameState = localStorage.getItem(`triviaGame_${currentDate}`);
    
    if (savedStreak) {
      setDailyStreak(parseInt(savedStreak));
    }

    if (savedGameState) {
      const gameState = JSON.parse(savedGameState);
      setGuessesLeft(gameState.guessesLeft);
      setGameStatus(gameState.gameStatus);
      setRevealedHints(gameState.revealedHints);
      setSubmittedGuesses(gameState.submittedGuesses);
    }
  }, [currentDate]);

  // Save game state to localStorage whenever it changes
  useEffect(() => {
    const gameState = {
      guessesLeft,
      gameStatus,
      revealedHints,
      submittedGuesses
    };
    localStorage.setItem(`triviaGame_${currentDate}`, JSON.stringify(gameState));
  }, [guessesLeft, gameStatus, revealedHints, submittedGuesses, currentDate]);

  const handleSubmitGuess = () => {
    if (!currentGuess.trim() || gameStatus !== 'playing') return;

    const newSubmittedGuesses = [...submittedGuesses, currentGuess];
    setSubmittedGuesses(newSubmittedGuesses);

    if (currentGuess.toLowerCase().trim() === triviaData.answer.toLowerCase()) {
      setGameStatus('won');
      // Update streak for correct answer
      const newStreak = dailyStreak + 1;
      setDailyStreak(newStreak);
      localStorage.setItem('dailyTriviaStreak', newStreak.toString());
    } else {
      const newGuessesLeft = guessesLeft - 1;
      setGuessesLeft(newGuessesLeft);
      
      if (newGuessesLeft === 0) {
        setGameStatus('lost');
        // Reset streak for incorrect answer (optional - you can remove this if you want to keep streak for participation)
        setDailyStreak(0);
        localStorage.setItem('dailyTriviaStreak', '0');
      }
    }
    
    setCurrentGuess('');
  };

  const handleRevealHint = (hintIndex: number) => {
    const newRevealedHints = [...revealedHints];
    newRevealedHints[hintIndex] = true;
    setRevealedHints(newRevealedHints);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmitGuess();
    }
  };

  const canPlayAgain = () => {
    // User can only play again when it's a new day (new puzzle)
    return false; // Since we only have one puzzle per day, they can't replay
  };

  return (
    <div className="min-h-screen bg-white px-4 py-8">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Date Header and Streak Counter */}
        <div className="text-center space-y-2">
          <h1 className="text-xl font-gotham-medium text-black mb-2">
            Date: {currentDate}
          </h1>
          <div className="text-lg font-gotham-medium text-black">
            Daily Questions Correct: {dailyStreak}
          </div>
        </div>

        {/* Question Box */}
        <div className="border-2 border-black rounded-2xl p-6">
          <p className="text-lg font-gotham-bold text-black leading-relaxed">
            {triviaData.question}
          </p>
        </div>

        {/* Answer Input Box */}
        <div className="border-2 border-black rounded-2xl p-6">
          <div className="space-y-4">
            <Input
              type="text"
              placeholder="answer is typed here"
              value={currentGuess}
              onChange={(e) => setCurrentGuess(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={gameStatus !== 'playing'}
              className="text-center font-gotham-medium text-black placeholder:text-gray-500 border-0 shadow-none text-lg focus-visible:ring-0"
            />
            
            {gameStatus === 'playing' && (
              <div className="flex justify-between items-center text-sm font-gotham-medium text-gray-600">
                <span>Guesses left: {guessesLeft}</span>
                <Button 
                  onClick={handleSubmitGuess}
                  disabled={!currentGuess.trim()}
                  className="bg-black text-white hover:bg-gray-800 font-gotham-medium"
                >
                  Submit
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Success/Failure Message */}
        {gameStatus === 'won' && (
          <div className="text-center space-y-2">
            <p className="text-2xl font-gotham-bold text-success">
              You got it!
            </p>
            <p className="font-gotham-medium text-black">
              Come back tomorrow for a new puzzle!
            </p>
          </div>
        )}

        {gameStatus === 'lost' && (
          <div className="text-center space-y-2">
            <p className="text-xl font-gotham-bold text-red-600">
              Game Over!
            </p>
            <p className="font-gotham-medium text-black">
              The answer was: <span className="font-gotham-bold">{triviaData.answer}</span>
            </p>
            <p className="font-gotham-medium text-black">
              Come back tomorrow for a new puzzle!
            </p>
          </div>
        )}

        {/* Previous Guesses */}
        {submittedGuesses.length > 0 && (
          <div className="space-y-2">
            <h3 className="font-gotham-medium text-black">Your guesses:</h3>
            <div className="space-y-1">
              {submittedGuesses.map((guess, index) => (
                <p key={index} className="font-gotham-medium text-gray-600 pl-4">
                  {index + 1}. {guess}
                </p>
              ))}
            </div>
          </div>
        )}

        {/* Hints */}
        <div className="space-y-4">
          {triviaData.hints.map((hint, index) => (
            <div key={index} className="border-2 border-black rounded-2xl p-6">
              {revealedHints[index] ? (
                <p className="font-gotham-medium text-black leading-relaxed">
                  {hint}
                </p>
              ) : (
                <div className="text-center">
                  <Button
                    onClick={() => handleRevealHint(index)}
                    className="bg-white text-black border-2 border-black hover:bg-gray-50 font-gotham-medium"
                    disabled={gameStatus !== 'playing'}
                  >
                    Hint {index + 1}
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TriviaGame;

